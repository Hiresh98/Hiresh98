VERBOSE = False #Set to True to get some messages
__all__ = ['matrix', 'factorize']
